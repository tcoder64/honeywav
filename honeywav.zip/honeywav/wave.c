
#include "wave.h"

/* little-endian helpers */
static void u16(FILE *f, uint16_t v) {
  fputc(v & 0xFF, f);
  fputc(v >> 8, f);
}
static void u32(FILE *f, uint32_t v) {
  fputc(v & 0xFF, f);
  fputc((v >> 8) & 0xFF, f);
  fputc((v >> 16) & 0xFF, f);
  fputc((v >> 24) & 0xFF, f);
}

static void write_header(wave_writer_t *w) {
  FILE *f = w->fp;
  fwrite("RIFF", 1, 4, f);
  u32(f, 0);
  fwrite("WAVE", 1, 4, f);

  fwrite("fmt ", 1, 4, f);
  u32(f, 16);
  u16(f, w->audio_format);
  u16(f, w->channels);
  u32(f, w->sample_rate);

  uint16_t block = w->channels * (w->bits_per_sample / 8);
  u32(f, w->sample_rate * block);
  u16(f, block);
  u16(f, w->bits_per_sample);

  fwrite("data", 1, 4, f);
  u32(f, 0);
}

int wave_open(wave_writer_t *w, const char *path, uint32_t sr, uint16_t ch,
              wave_format_t fmt) {
  w->fp = fopen(path, "wb");
  if (!w->fp)
    return 0;

  w->sample_rate = sr;
  w->channels = ch;
  w->data_bytes = 0;

  if (fmt == WAVE_PCM16) {
    w->bits_per_sample = 16;
    w->audio_format = 1;
  }
  if (fmt == WAVE_PCM32) {
    w->bits_per_sample = 32;
    w->audio_format = 1;
  }
  if (fmt == WAVE_FLOAT32) {
    w->bits_per_sample = 32;
    w->audio_format = 3;
  }

  write_header(w);
  return 1;
}

int wave_write_frames(wave_writer_t *w, const void *frames, uint32_t count) {
  uint32_t bytes = count * w->channels * (w->bits_per_sample / 8);
  fwrite(frames, 1, bytes, w->fp);
  w->data_bytes += bytes;
  return 1;
}

int wave_close(wave_writer_t *w) {
  FILE *f = w->fp;
  fseek(f, 40, SEEK_SET);
  u32(f, w->data_bytes);
  fseek(f, 4, SEEK_SET);
  u32(f, 36 + w->data_bytes);
  fclose(f);
  return 1;
}
