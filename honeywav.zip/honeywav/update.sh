gcc -shared -fPIC wave.c dsp.c -o honeywav/_honeywav.so -lm
