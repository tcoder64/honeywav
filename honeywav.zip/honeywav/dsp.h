
#ifndef DSP_H
#define DSP_H

#include "wave.h"

void dsp_silence(wave_writer_t *w, float sec);
void dsp_tone(wave_writer_t *w, float freq, float sec, float amp);

#endif
