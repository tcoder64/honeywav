import ctypes
from ctypes import POINTER, c_void_p, c_float, c_uint16, c_uint32, c_int, byref
import os

# ------------------- Load shared library -------------------
_lib_file = "_honeywav.so"
_lib_path = os.path.join(os.path.dirname(__file__), _lib_file)

if not os.path.exists(_lib_path):
    raise FileNotFoundError(f"Cannot find {_lib_path} at {_lib_path}")

_lib = ctypes.cdll.LoadLibrary(_lib_path)


# ------------------- Hidden WaveWriter -------------------
class _WaveWriter(ctypes.Structure):
    _fields_ = [
        ("fp", c_void_p),
        ("sample_rate", c_uint32),
        ("channels", c_uint16),
        ("bits_per_sample", c_uint16),
        ("audio_format", c_uint16),
        ("data_bytes", c_uint32),
    ]


# ------------------- Function signatures -------------------
_lib.wave_open.argtypes = [
    POINTER(_WaveWriter),
    ctypes.c_char_p,
    c_uint32,
    c_uint16,
    c_int,
]
_lib.wave_open.restype = c_int

_lib.wave_write_frames.argtypes = [POINTER(_WaveWriter), POINTER(c_float), c_uint32]
_lib.wave_write_frames.restype = c_int

_lib.wave_close.argtypes = [POINTER(_WaveWriter)]
_lib.wave_close.restype = c_int


# ------------------- Wave class -------------------
class Wave:
    PCM16 = 0
    PCM32 = 1
    FLOAT32 = 2

    def __init__(self, path, sample_rate=48000, channels=1, fmt=2):
        self._w = _WaveWriter()
        ret = _lib.wave_open(
            byref(self._w), path.encode("utf-8"), sample_rate, channels, fmt
        )
        if ret != 1:
            raise RuntimeError(f"wave_open failed with code {ret}")

    def write_frames(self, frames):
        # Accept list or tuple
        buf = (c_float * len(frames))(*frames)
        _lib.wave_write_frames(byref(self._w), buf, len(frames))

    def close(self):
        if self._w.fp:
            _lib.wave_close(byref(self._w))
            self._w.fp = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ------------------- Convenience functions -------------------
def open(path, sample_rate=48000, channels=1, fmt=2):
    """Open a wave file for 'with wav.open(...) as w:'"""
    return Wave(path, sample_rate, channels, fmt)


def close(wave_obj):
    """Optional manual close"""
    wave_obj.close()
