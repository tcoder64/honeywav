import ctypes
from ctypes import c_float, byref
from .__init__ import _WaveWriter, _lib  # reuse hidden struct and lib


# ------------------- DSP functions -------------------
def silence(wave_obj, seconds: float):
    """Insert silence into the wave."""
    _lib.dsp_silence(byref(wave_obj._w), c_float(seconds))


def tone(wave_obj, freq: float, seconds: float, amp: float):
    """Generate a tone into the wave."""
    _lib.dsp_tone(byref(wave_obj._w), c_float(freq), c_float(seconds), c_float(amp))
