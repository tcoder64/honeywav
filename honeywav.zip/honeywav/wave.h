
#ifndef WAVE_H
#define WAVE_H

#include <stdint.h>
#include <stdio.h>

typedef enum { WAVE_PCM16, WAVE_PCM32, WAVE_FLOAT32 } wave_format_t;

typedef struct {
  FILE *fp;
  uint32_t sample_rate;
  uint16_t channels;
  uint16_t bits_per_sample;
  uint16_t audio_format; // 1=PCM, 3=float
  uint32_t data_bytes;
} wave_writer_t;

int wave_open(wave_writer_t *w, const char *path, uint32_t sample_rate,
              uint16_t channels, wave_format_t format);

int wave_write_frames(wave_writer_t *w, const void *frames,
                      uint32_t frame_count);

int wave_close(wave_writer_t *w);

#endif
