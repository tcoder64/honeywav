
#include "dsp.h"
#include <math.h>

void dsp_silence(wave_writer_t *w, float sec) {
  int n = (int)(sec * w->sample_rate);
  float zero = 0.0f;
  for (int i = 0; i < n; i++)
    wave_write_frames(w, &zero, 1);
}

void dsp_tone(wave_writer_t *w, float freq, float sec, float amp) {
  int n = (int)(sec * w->sample_rate);
  float phase = 0.0f;
  float step = 2.0f * M_PI * freq / w->sample_rate;

  for (int i = 0; i < n; i++) {
    float s = amp * sinf(phase);
    phase += step;
    wave_write_frames(w, &s, 1);
  }
}
